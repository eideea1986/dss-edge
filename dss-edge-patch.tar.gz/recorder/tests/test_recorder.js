const { startRecording } = require("../recorder");

// Mock RTSP URL (use a test file or local stream if available in prod)
// For test, we might normally use a local file input, but here we just import to syntax check
console.log("Recorder module loaded.");
