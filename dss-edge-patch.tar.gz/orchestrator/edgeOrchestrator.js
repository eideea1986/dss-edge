const { spawn } = require("child_process");
const path = require("path");
const http = require('http');

// CONFIGURATION
const MAX_RESTART_DELAY = 60000; // 1 min max backoff
const INITIAL_RESTART_DELAY = 2000;
const HEALTH_CHECK_INTERVAL = 5000; // Check every 5s

// SERVICES DEFINITION
const services = [
    {
        name: "Go2RTC",
        external: true, // Managed by systemd
        systemd: "dss-go2rtc",
        healthUrl: "http://127.0.0.1:1984/api/streams",
        critical: true,
        status: "UNKNOWN",
        backoff: INITIAL_RESTART_DELAY
    },
    {
        name: "Local API",
        cmd: "node",
        args: ["local-api/server.js"],
        waitFor: ["Go2RTC"], // Dependency: API needs streams
        healthUrl: "http://127.0.0.1:8080/status", // Ensure server.js implements this!
        critical: true,
        status: "STOPPED",
        backoff: INITIAL_RESTART_DELAY
    },
    {
        name: "Recorder",
        cmd: "node",
        args: ["recorder/recorder.js"],
        waitFor: ["Local API"], // Recorder needs Config from API
        healthUrl: "http://127.0.0.1:3000/status", // Assuming recorder exposes status
        critical: false,
        status: "STOPPED",
        backoff: INITIAL_RESTART_DELAY
    }
];

const processes = {};

function log(msg) {
    console.log(`[${new Date().toISOString()}] [ORCHESTRATOR] ${msg}`);
}

// HEALTH CHECKER
async function checkHealth(service) {
    if (!service.healthUrl) return true;

    return new Promise(resolve => {
        const req = http.get(service.healthUrl, (res) => {
            if (res.statusCode === 200) resolve(true);
            else resolve(false);
        });
        req.on('error', () => resolve(false));
        req.setTimeout(2000, () => {
            req.destroy();
            resolve(false);
        });
    });
}

// DEPENDENCY CHECKER
function areDependenciesMet(service) {
    if (!service.waitFor || service.waitFor.length === 0) return true;

    return service.waitFor.every(depName => {
        const dep = services.find(s => s.name === depName);
        // Dependency is met if it's RUNNING or HEALTHY
        return dep && (dep.status === "RUNNING" || dep.status === "HEALTHY");
    });
}

// PROCESS STARTER
function startService(service) {
    if (service.external) return;
    if (service.status === "STARTING" || service.status === "RUNNING" || service.status === "HEALTHY") return;

    if (!areDependenciesMet(service)) {
        // Silent wait, will be retried by loop or recursion
        return;
    }

    log(`Starting ${service.name}...`);
    service.status = "STARTING";

    const p = spawn(service.cmd, service.args, {
        stdio: "inherit",
        cwd: path.resolve(__dirname, ".."),
        env: { ...process.env, NODE_ENV: 'production' }
    });

    processes[service.name] = p;

    p.on("spawn", () => {
        service.status = "RUNNING";
        service.backoff = INITIAL_RESTART_DELAY; // Reset backoff on success
        log(`${service.name} is RUNNING (PID: ${p.pid})`);
    });

    p.on("exit", (code) => {
        service.status = "CRASHED";
        log(`${service.name} exited with code ${code}. Restarting in ${service.backoff / 1000}s...`);

        setTimeout(() => {
            service.status = "STOPPED"; // Ready to retry
            startService(service);
        }, service.backoff);

        service.backoff = Math.min(service.backoff * 2, MAX_RESTART_DELAY);
    });

    p.on("error", (err) => {
        log(`${service.name} Spawn Error: ${err.message}`);
        service.status = "CRASHED";
    });
}

// MONITOR LOOP
async function monitorLoop() {
    for (const service of services) {
        // 1. Check Health & Update Status
        const isHealthy = await checkHealth(service);

        if (service.external) {
            service.status = isHealthy ? "HEALTHY" : "DOWN";
            if (service.status === "DOWN") {
                // log(`${service.name} is DOWN (External)`);
            }
        } else {
            // Upgrade internal status to HEALTHY if running + healthy check pass
            if (service.status === "RUNNING" && isHealthy) {
                service.status = "HEALTHY";
            }
        }

        // 2. Try to start stopped/pending services if deps are met
        if (!service.external && (service.status === "STOPPED" || service.status === "CRASHED")) {
            // Check if we are in backoff wait? No, backoff handles the timeout callback.
            // But if it was STOPPED initially (not crashed), start it.
            if (processes[service.name] === undefined && areDependenciesMet(service)) { // Never started
                startService(service);
            }
            // If dependecies just became met
            if (areDependenciesMet(service) && !service.timer && service.status === "STOPPED") {
                startService(service);
            }
        }
    }
}

// STARTUP
log("Starting Enterprise Orchestrator...");
monitorLoop();
setInterval(monitorLoop, HEALTH_CHECK_INTERVAL);

// Keep process alive
setInterval(() => { }, 60000);
