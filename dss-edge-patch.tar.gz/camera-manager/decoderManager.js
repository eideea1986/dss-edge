/* camera-manager/decoderManager.js - Persistent Pipe Decoder (Trassir Standard) */
const { spawn } = require('child_process');
const cameraStore = require('../local-api/store/cameraStore');
const path = require('path');
const fs = require('fs');

const RAMDISK_DIR = path.resolve(__dirname, '../recorder/ramdisk/snapshots');

class DecoderManager {
    constructor() {
        this.processes = new Map(); // cameraId -> ChildProcess
    }

    startAll() {
        if (!fs.existsSync(RAMDISK_DIR)) fs.mkdirSync(RAMDISK_DIR, { recursive: true });
        console.log("[Decoder] Initializing persistent pipeline...");
        cameraStore.list().forEach(cam => this.startDecoder(cam));
    }

    startDecoder(cam) {
        if (this.processes.has(cam.id)) return;

        // CRITICAL: Pull from Go2RTC Loopback, NOT Camera directly.
        // This allows Go2RTC to multiplex the single allowed connection from the camera.
        const loopbackRtsp = `rtsp://127.0.0.1:8554/${cam.id}`;

        // Use loopback by default. If Go2RTC is down, this will fail and retry, which is fine.
        const rtspUrl = loopbackRtsp;

        const snapPath = path.join(RAMDISK_DIR, `${cam.id}.jpg`);

        // ARGS: Continuous Frame Decode -> stdout
        const args = [
            '-loglevel', 'error',
            '-rtsp_transport', 'tcp', // Connect to Go2RTC via TCP
            '-i', rtspUrl,
            '-vf', 'fps=1',
            '-f', 'image2pipe',
            '-vcodec', 'mjpeg',
            'pipe:1'
        ];

        const p = spawn('ffmpeg', args);
        this.processes.set(cam.id, p);

        console.log(`[Decoder] Persistent stream started for ${cam.id}`);

        // PULSE: Every time a frame (JPEG data) hits the pipe, CAMERA IS ONLINE
        p.stdout.on('data', (chunk) => {
            // We got bytes = We have video life
            cameraStore.updateLastFrame(cam.id);

            // OPTIONAL: Write the actual image to ramdisk for AI/Preview
            // Since it's mjpeg pipe, we can just write the last full buffer 
            // but for absolute stability we do it simply:
            if (chunk.length > 5000) { // Typical MJPEG frame size min
                fs.writeFile(snapPath, chunk, (err) => { });
            }
        });

        // CONSUME STDERR (Critical to prevent freeze)
        p.stderr.on('data', (data) => {
            console.error(`[Decoder ${cam.id}] Error: ${data.toString()}`);
        });

        p.on('exit', (code) => {
            if (this.processes.has(cam.id)) {
                this.processes.delete(cam.id);
                console.warn(`[Decoder] Camera ${cam.id} died (code ${code}). Restarting in 5s...`);
                setTimeout(() => this.startDecoder(cam), 5000);
            }
        });
    }

    stopAll() {
        for (const [id, p] of this.processes) {
            this.processes.delete(id);
            p.kill();
        }
    }
}

module.exports = new DecoderManager();
