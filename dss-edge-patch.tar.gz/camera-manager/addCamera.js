/* addCamera.js - Unified Add Camera with Smart Probe */
const crypto = require('crypto');
const validateRtsp = require('./validateRtsp');
const startStream = require('./startStream');
const decoderManager = require('./decoderManager');
const cameraStore = require('../local-api/store/cameraStore');
const DeviceFactory = require('./adapters/DeviceFactory');

/**
 * Enterprise-grade RTSP auto-detection fallback.
 * Used only if Smart Probe fails.
 */
function autoGenerateRTSP(data) {
    const { ip, user, pass, manufacturer, vendor } = data;
    const mfg = (manufacturer || vendor || "").toLowerCase();
    const usr = user || 'admin';
    const pwd = pass || '';
    const auth = `${usr}:${pwd}@${ip}`;

    if (mfg.includes("hikvision")) {
        return {
            main: `rtsp://${auth}:554/Streaming/Channels/101`,
            sub: `rtsp://${auth}:554/Streaming/Channels/102`
        };
    } else if (mfg.includes("dahua")) {
        return {
            main: `rtsp://${auth}:554/cam/realmonitor?channel=1&subtype=0`,
            sub: `rtsp://${auth}:554/cam/realmonitor?channel=1&subtype=1`
        };
    }

    // Generic Fallback
    return {
        main: `rtsp://${auth}:554/stream1`,
        sub: `rtsp://${auth}:554/stream2`
    };
}

module.exports = async function addCamera(data) {
    console.log(`[AddCamera] Received request for: ${data.ip || data.rtsp}`);

    let id = data.id || `cam_${crypto.randomUUID().split('-')[0]}`;
    let camera = {
        id,
        name: data.name || (data.ip ? `${data.manufacturer || 'Camera'} ${data.ip}` : `Camera ${id.substring(0, 8)}`),
        vendor: data.manufacturer || data.vendor || "Generic",
        ip: data.ip || "",
        credentials: {
            user: data.user || "admin",
            pass: data.pass || ""
        },
        streams: {
            main: data.rtsp || "",
            sub: data.rtspSub || data.rtsp || ""
        },
        fps: data.fps || 5,
        status: "OFFLINE",
        record: data.record !== undefined ? data.record : true,
        ai: data.ai !== undefined ? data.ai : false,
        createdAt: new Date().toISOString()
    };

    // 1. Initial Logic: If URLs NOT provided, fill temporarily with template or wait for probe
    if (!camera.streams.main && camera.ip) {
        const generated = autoGenerateRTSP(data);
        camera.streams.main = generated.main;
        if (!camera.streams.sub) camera.streams.sub = generated.sub;
        console.log(`[AddCamera] Temporary RTSP (Template): ${camera.streams.main}`);
    }

    if (!camera.streams.main) {
        throw new Error("RTSP URL or IP required.");
    }

    // 2. Duplicate Check
    const existing = cameraStore.findByRtsp(camera.streams.main);
    if (existing) {
        throw new Error(`Duplicate Camera: RTSP already used by ${existing.name}`);
    }

    // 3. Persist Initial State (Quick Response)
    cameraStore.add(camera);
    console.log(`[AddCamera] Camera ${camera.id} persisted. Starting background activation...`);

    // 4. BACKGROUND INTELLIGENCE (The "Trassir" Magic)
    (async () => {
        try {
            let configUpdated = false;

            // A. Try Smart Probe to get REAL URLs and Model ONLY if manually provided URLs were missing/generic
            // or we want to confirm validity. We do it if IP and User are present.
            if (camera.ip && camera.credentials.user) {
                console.log(`[AddCamera] 🚀 Launching Smart Probe for ${camera.ip}...`);
                const probeResult = await DeviceFactory.smartProbe({
                    ip: camera.ip,
                    user: camera.credentials.user,
                    pass: camera.credentials.pass,
                    manufacturer: camera.vendor,
                    port: parseInt(data.port) || 80
                });

                if (probeResult && probeResult.config) {
                    console.log(`[AddCamera] 🎯 Smart Probe Match! Updating Config for ${camera.id}`);

                    // Update Camera with discovered truths
                    const betterCam = {
                        ...camera,
                        vendor: probeResult.config.manufacturer || camera.vendor,
                        model: probeResult.config.model || "Detected Device",
                        streams: {
                            main: probeResult.config.streams?.main || probeResult.config.rtspHd || camera.streams.main,
                            sub: probeResult.config.streams?.sub || probeResult.config.rtsp || camera.streams.sub
                        }
                    };

                    // Update name if it was generic
                    if (betterCam.name.includes("Camera cam_") || betterCam.name.includes("Auto-Detect")) {
                        betterCam.name = `${betterCam.vendor} ${betterCam.ip}`;
                    }

                    cameraStore.add(betterCam);
                    camera = betterCam; // Refresh ref
                    configUpdated = true;
                    console.log(`[AddCamera] Config Updated: Main=${camera.streams.main}`);
                } else {
                    console.warn(`[AddCamera] Smart Probe yielded no results. Keeping templates.`);
                }
            }

            // B. Start Services
            await startStream(camera);

            // If we just updated the config, ensure decoder gets the fresh object
            decoderManager.startDecoder(camera);

            console.log(`[AddCamera] ✅ Activation Sequence Complete for ${camera.id}`);

        } catch (e) {
            console.error(`[AddCamera] ❌ Background Activation Failed for ${camera.id}:`, e.message);
        }
    })();

    // Return immediately
    return camera;
};
