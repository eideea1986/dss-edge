/* local-api/store/cameraStore.js - SINGLE SOURCE OF TRUTH (Strict Trassir Logic) */
const fs = require('fs');
const path = require('path');

const CONFIG_FILE = path.resolve(__dirname, '../../config/cameras.json');
const ABS_CONFIG_PATH = path.normalize(CONFIG_FILE);

class CameraStore {
    constructor() {
        this.cache = new Map();
        this.load();
    }

    load() {
        try {
            if (fs.existsSync(ABS_CONFIG_PATH)) {
                const raw = fs.readFileSync(ABS_CONFIG_PATH, 'utf8');
                const data = JSON.parse(raw);
                if (Array.isArray(data)) {
                    this.cache.clear();
                    data.forEach(c => {
                        if (c.id) {
                            c.status = "OFFLINE"; // Start all as OFFLINE
                            this.cache.set(c.id, c);
                        }
                    });
                }
            }
        } catch (e) { }
    }

    save() {
        try {
            const list = [...this.cache.values()].map(c => {
                const copy = { ...c };
                delete copy.lastFrameAt;
                return copy;
            });
            fs.writeFileSync(ABS_CONFIG_PATH, JSON.stringify(list, null, 4));
        } catch (e) { }
    }

    // THE DEFINITIVE TRIGGER: EVIDENCE OF LIFE
    updateLastFrame(id) {
        const cam = this.cache.get(id);
        if (!cam) return;

        cam.lastFrameAt = Date.now();
        if (cam.status !== "ONLINE") {
            cam.status = "ONLINE";
            console.log(`[Store] ${cam.name} -> ONLINE (Real Video Detected)`);
            this.save();
        }
    }

    add(camera) { this.cache.set(camera.id, camera); this.save(); }
    get(id) { return this.cache.get(id); }
    update(id, partial) {
        const cam = this.cache.get(id);
        if (!cam) return null;
        Object.assign(cam, partial);
        this.save();
        return cam;
    }
    delete(id) {
        const existed = this.cache.delete(id);
        if (existed) this.save();
        return existed;
    }
    list() { return [...this.cache.values()]; }
    findByRtsp(rtsp) {
        for (const cam of this.cache.values()) {
            if (cam.streams?.main === rtsp || cam.streams?.sub === rtsp) return cam;
        }
        return null;
    }
}

module.exports = new CameraStore();
