const rec = require('./services/recorderService');
rec.init();
setInterval(() => { }, 1000); // Keep alive
